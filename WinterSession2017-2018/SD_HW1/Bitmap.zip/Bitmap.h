#pragma once
#include <fstream>

struct BmpSignature;
struct BmpHeader;
struct BmpInfoHeader;
struct Pixel;

class Bitmap {
    std::ifstream ifsBmp_;
    int buffLength_;
    char* buffer_;

    int height_;
    int width_;

    BmpSignature *signature_;
    BmpHeader *header_;
    BmpInfoHeader *info_;
    Pixel** pix_;

    void resize(int, int);
    void readFile();
public:
    Bitmap();
    Bitmap(char*);
    ~Bitmap();

    const int getHeight() const;
    const int getWidth() const;

    
    void writeIcon(int, int, int, int, char*);
};