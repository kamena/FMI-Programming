#include "Bitmap.h"

struct BmpSignature {
    unsigned char data[2];
};

struct BmpHeader {
    unsigned int fileSize;
    unsigned short reserved1;
    unsigned short reserved2;
    unsigned int dataOffset;
};

struct BmpInfoHeader { 
    unsigned int  biSize;
             int  biWidth;
             int  biHeight;
    unsigned int  biPlanes;
    unsigned int  biBitCount;
};

struct Pixel {
    char blue;
    char green;
    char red;
};

Bitmap::Bitmap() {
    
}

Bitmap::Bitmap(char* fileName) {
    std::cout << "Sad";
    this->ifsBmp_.open(fileName, std::ios::binary);
    if(!ifsBmp_) std::cerr << "Error: Fail to open file. " << std::endl;
}

Bitmap::~Bitmap() {
    ifsBmp_.close();
    //deallocate the array
    for(int i = 0; i < height_; i++)
        delete[] pix_[i];
    delete[] pix_;
}

const int Bitmap::getHeight() const {
    return this->info_->biWidth;
}

const int Bitmap::getWidth() const {
    return this->info_->biHeight;
}

void Bitmap::resize(int newWidth, int newHeight) {
    this->info_->biWidth = newWidth;
    this->info_->biHeight = newHeight;
}

void Bitmap::readFile() {
    if(!ifsBmp_)
        return;
    // Read header
    ifsBmp_.seekg(0, std::ios::beg);
    ifsBmp_.read((char*) &signature_, sizeof(signature_));
    ifsBmp_.read((char*) &header_, sizeof(header_));
    ifsBmp_.read((char*) &info_, sizeof(info_));

    // Read all of the rest bytes between the header and the pixels
    buffLength_ = header_->dataOffset - ifsBmp_.tellg();  
    buffer_ = new char[buffLength_];
    ifsBmp_.read(buffer_, buffLength_);

    // Read pixels
    height_ = getHeight();
    width_ = getWidth();
    // this->pix_ = new Pixel**[height_][width_];

    //allocate the array
    pix_ = new Pixel*[height_];
    for(int i = 0; i < height_; i++)
        pix_[i] = new Pixel[width_];
    
    ifsBmp_.seekg(header_->dataOffset, std::ios::beg);
    ifsBmp_.read((char*) &pix_, sizeof(pix_));

}

void Bitmap::writeIcon(int x, int y, int iconWidth, int iconHeight, char* newFileName) {
    std::ofstream ofsBmp;
    ofsBmp.open(newFileName, std::ios::binary);
    if(!ofsBmp) std::cerr << "Error opening the file" << std::endl;
    std::cout << "Success!";    

    ofsBmp.write((char*) &signature_, sizeof(signature_));
    ofsBmp.write((char*) &header_, sizeof(header_));

    resize(iconWidth, iconHeight);

    ofsBmp.write((char*) &info_, sizeof(info_));

    ofsBmp.write((char*) &buffer_, buffLength_);

    // Write the selected pixels in the new file
    for(int i = 0; i < iconWidth; i++) {
        for(int j = 0; j < iconHeight; j++){
            ofsBmp.write((char*) &pix_[i][j], sizeof(Pixel));
        }
    }

    ofsBmp.close();
}
